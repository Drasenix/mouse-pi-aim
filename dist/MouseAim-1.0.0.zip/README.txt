MOUSE: P.I. For Hire - Mouse Aim
Version 1.0.0

WHAT IT DOES
Hold a dedicated key to aim. The camera zooms in and weapon spread is reduced.
- Default aim button: middle mouse button (hold to aim, release to stop).
- Smooth camera FOV zoom.
- Reduced spread while aiming; the crosshair tightens automatically.
- Dedicated, configurable aim button: MiddleMouse, RightMouse, Mouse4, Mouse5,
  or a keyboard key such as LeftShift or V.
- Does not use the game's AlternateShoot action, so it does not conflict with
  secondary fire or native weapon scopes.

VERSION 1.0.0 LIMITATIONS
- No weapon animation or weapon pose change: the weapon stays in its normal
  pose while aiming.
- No sensitivity or recoil change.
- Generic aim is skipped while a weapon's secondary ability is active (native
  scope or alternate fire), to avoid stacking two zoom effects.

REQUIREMENTS
- MOUSE: P.I. For Hire (tested with the 14/10/2026 build).
- BepInEx 5.4.23.5 x64 for MOUSE: P.I. For Hire, with the game-specific
  "unstripped" setup.
  On Nexus, use "Unstripped BepInEx for M.P.I.".
  Do NOT use a stock BepInEx package: this game ships stripped BCL assemblies
  and the preloader will fail.
- Single-player. No anti-cheat is involved.

INSTALL
1. Install the BepInEx unstripped package into the game root (the folder
   containing MOUSE.exe).
2. Launch the game once, then check that BepInEx/LogOutput.log exists.
3. Extract this archive into the game root. The result must be:
   <game>/BepInEx/plugins/MouseAim.dll
4. Launch the game.
5. Hold the middle mouse button while a weapon is drawn.

CONFIG
File: BepInEx/config/com.cono.mouseaim.cfg

[General]
Enabled = true
AimButton = MiddleMouse

[Zoom]
AimZoomDegrees = 20
AimTransitionSeconds = 0.15

[Accuracy]
AimSpreadMultiplier = 0.5

[Conditions]
RequireWeaponDrawn = true

[Debug]
Verbose = false

- AimZoomDegrees = 0: accuracy only, no zoom.
- AimSpreadMultiplier = 1: zoom only, no accuracy change.
- AimButton: MiddleMouse, RightMouse, Mouse4, Mouse5, or a keyboard key.
  MiddleMouse is recommended; RightMouse may conflict with secondary fire or
  native scopes.

Change the values in the file and restart the game.

UNINSTALL
Delete:
BepInEx/plugins/MouseAim.dll

NOTES
- Tested with the 14/10/2026 game build and BepInEx 5.4.23.5 (unstripped).
- If zoom or accuracy stops working after a game update, check
  BepInEx/LogOutput.log for "MouseAim".
- Linux / Steam Proton / Lutris: install the Windows BepInEx package in the
  game folder. No special launch options are required.
